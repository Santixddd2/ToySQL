#Class data for save the data 
class data:
    def __init__(self,data,id):
        self.data=data
        self.id=id